# Version 1.0.1
### Fixes
ModUI shader settings now accept either `myShader` or `myShader.bundle` as valid input
###### Note: `myShader` should be replaced with the name of the bundle you'd like to use.