# Version 1.0.2
### Additions
Added a "Clear Cache" bind (Hold `F6` for 3 seconds) to allow for hot-reload of structure shaders, allowing developers to iterrate on shaders faster without having to restart their games.

### Fixes
Fixed issues in material application logic which caused structures to take the wrong material properties when reloaded using `F5`.

# Version 1.0.1
### Fixes
ModUI shader settings now accept either `myShader` or `myShader.bundle` as valid input
###### Note: `myShader` should be replaced with the name of the bundle you'd like to use.