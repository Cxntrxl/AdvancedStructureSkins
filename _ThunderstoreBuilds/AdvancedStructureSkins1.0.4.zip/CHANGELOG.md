# Version 1.0.4
### Additions
Added random texture selection! If you want to use multiple textures, add your textures to a subfolder under the `StructureName`, and the game will automatically select between different skins randomly. If you want to disable this functionality without deleting the skin permanently, just add an Underscore (`_`) to the beginning of the folder name and the game will ignore it.

Example folder structure:
```
RUMBLE
| - UserData
|   | - Skins
|   |   | - StructureName
|   |   |   | - SkinName (can be anything)
|   |   |   |   | - Main.png
|   |   |   |   | - Normal.png
|   |   |   |   | - Mat.png
|   |   |   |   | - Grounded.png
|   |   |   | - SkinName2
|   |   |   |   | - Main.png
|   |   |   |   | - Normal.png
|   |   |   |   | - Mat.png
|   |   |   |   | - Grounded.png
```

If you want to use multiple textures of the same type for a single skin (like if you wanted a playing card which changed the `Main` texture randomly, but kept the same `Normal`, simply add a folder for that type of texture to your `SkinName` folder.
Example:
```
RUMBLE
| - UserData
|   | - Skins
|   |   | - StructureName
|   |   |   | - SkinName (can be anything)
|   |   |   |   | - Main
|   |   |   |   |   | - tex1.png (can be anything)
|   |   |   |   |   | - tex2.png (can be anything)
|   |   |   |   |   | - tex3.png (can be anything)
|   |   |   |   | - Normal.png
|   |   |   |   | - Mat.png
|   |   |   |   | - Grounded.png
```

Also, textures can now be hot-reloaded by holding `F6` while in game. This means you can swap in and out textures from your game files and reload the ones you're using on the fly, without having to restart your game.

# Version 1.0.3
### Additions
Added random shader selection! Enter `random` as the ModUI shader settings to select a random shader from your `/RUMBLE/UserData/Skins/` folder.
Enter `StructureType/random` to select from the shaders in `/RUMBLE/UserData/Skins/StructureType/` folder, allowing for a different random pool per structure.

### Fixes
Fixed issues in material caching which caused balls to revert to default shading after entering a multiplayer scene.

# Version 1.0.2
### Additions
Added a "Clear Cache" bind (Hold `F6` for 3 seconds) to allow for hot-reload of structure shaders, allowing developers to iterrate on shaders faster without having to restart their games.

### Fixes
Fixed issues in material application logic which caused structures to take the wrong material properties when reloaded using `F5`.

# Version 1.0.1
### Fixes
ModUI shader settings now accept either `myShader` or `myShader.bundle` as valid input
###### Note: `myShader` should be replaced with the name of the bundle you'd like to use.